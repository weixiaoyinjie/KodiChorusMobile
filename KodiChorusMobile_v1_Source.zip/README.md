# Kodi Chorus 大字版 v1.0（Android）

**目标：把 Kodi 当前的 Chorus2 网页原封不动地作为一个独立手机 App 使用。**

- 不再开发重复的原生 Kodi 遥控器；App 加载电视端现有的 **Chorus2 网页**。
- 电影、音乐、视频、图片、插件和 Chorus2 已支持的 Kodi 设置都由原网页提供。
- 可调整大字体（100%–220%），并开启/关闭较大的点击区域。
- 去除 Chrome 地址栏，保留极简工具栏。可隐藏工具栏，按手机**返回键**恢复。
- 支持网页登录、HTTP Basic Auth、WebSocket、下载、文件选择、刷新和页面后退。
- 默认访问 `http://192.168.0.52:8080/`；IP、端口、Kodi HTTP 账号与密码可在 App 内配置。
- HTTP/局域网专用，不使用云端 API、广告或第三方账号。

## 使用前准备

Google TV 的 Kodi 打开：**设置 → 服务 → 控制 → 允许通过 HTTP 进行远程控制**。网页界面选择 **Kodi web interface – Chorus2**，记住端口与 HTTP 账号密码。请保持手机与电视盒子位于可互通的局域网。

## GitHub Actions 编译 APK（无需电脑 Android Studio）

1. 在 GitHub 创建空的公开或私有仓库。
2. 将压缩包 **内部所有文件夹和文件** 上传到仓库根目录（不是把 ZIP 本身作为唯一文件上传）。其中 `.github/workflows/build-apk.yml` 必须保留在原始目录。
3. 点击 **Actions → Build Kodi Chorus Mobile APK → Run workflow**；如果已推送到 main/master，会自动启动。
4. 完成后从 Actions 运行记录的 **Artifacts → KodiChorusMobile-v1-debug-apk** 下载压缩包，解压后安装 `app-debug.apk`。
5. 安装后第一次打开，自动加载预设 Kodi IP 地址。右上角 **⋮ → 连接地址 / 字体 / 布局设置** 可修改。

## 本地编译

需要 **JDK 17、Android SDK API 35、Gradle 8.9**。在源码根目录执行：

```bash
gradle --no-daemon :app:assembleDebug
```

APK 位置：`app/build/outputs/apk/debug/app-debug.apk`。

## 界面按钮

- `A− / A+`：字号每次降低/增加 10%。
- `⛶`：隐藏工具栏，扩展网页空间；按手机返回键恢复工具栏。
- `⋮`：连接设置、字号滑杆、刷新、回首页、外部浏览器、清理缓存。
- 页面本身全部来自电视端当前的 Chorus2，可以左右滚动、双指缩放。

## 限制与安全

1. **Chorus2 官方网页没有开放的 Kodi 设置，App 也无法凭包装后自动增加。** 需到电视 Kodi 界面修改那部分设置。
2. 只在局域网中连接 Kodi，电视端 Kodi 不运行时不能使用；手机离开局域网也不能访问。
3. App 内增大字体和按钮是覆盖样式，不是对 Chorus2 源码的永久修改。若 Kodi 更新改变页面元素，个别界面可能需要调整样式以避免裁切。
4. Kodi Web 服务器使用 HTTP 时，密码在局域网传输不加密。请使用可信网络，严禁将 8080/JSON-RPC 端口映射到公网。
5. 本仓库不包含 Kodi / Chorus2 的网页源文件。网页由正在运行的 Kodi 提供。
6. 目前为源码版，APK 需要使用 GitHub Actions 或 Android 构建环境编译；尚未进行真机安装验证。

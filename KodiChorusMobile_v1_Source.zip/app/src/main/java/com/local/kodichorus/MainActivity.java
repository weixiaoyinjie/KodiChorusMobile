package com.local.kodichorus;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.HttpAuthHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A dedicated, full-featured Android container for the LIVE Kodi Chorus2 web UI.
 * No replacement remote UI; the server's actual media/settings pages stay intact.
 */
public final class MainActivity extends Activity {
    private static final int PICK_FILE = 720;
    private static final String PREFS = "chorus_prefs";
    private static final int BG = Color.rgb(20, 27, 32);
    private static final int FG = Color.WHITE;
    private SharedPreferences preferences;
    private WebView web;
    private LinearLayout toolbar;
    private TextView title, errorBanner, fontLabel;
    private ProgressBar progress;
    private ValueCallback<Uri[]> fileCallback;
    private String host, username, password;
    private int port, fontPercent;
    private boolean largeTargets, fullscreen;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        readPreferences();
        buildScreen();
        configureWebView();
        if (savedInstanceState != null && web.restoreState(savedInstanceState) != null) {
            injectCss();
        } else {
            loadKodi();
        }
    }

    private void readPreferences() {
        host = preferences.getString("host", "192.168.0.52").trim();
        port = preferences.getInt("port", 8080);
        username = preferences.getString("username", "");
        password = preferences.getString("password", "");
        fontPercent = preferences.getInt("font", 150);
        largeTargets = preferences.getBoolean("largeTargets", true);
        fullscreen = preferences.getBoolean("fullscreen", false);
    }

    private int dp(float d) { return (int) (getResources().getDisplayMetrics().density * d + 0.5f); }

    private Button toolbarButton(String glyph, String accessibleName) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(glyph);
        b.setTextColor(FG);
        b.setTextSize(16);
        b.setPadding(0, 0, 0, 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setContentDescription(accessibleName);
        toolbar.addView(b, new LinearLayout.LayoutParams(dp(46), dp(48)));
        return b;
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);

        toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setBackgroundColor(BG);
        root.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(48)));

        title = new TextView(this);
        title.setText("Chorus2");
        title.setTextColor(FG);
        title.setTextSize(17);
        title.setSingleLine(true);
        title.setPadding(dp(14), 0, 0, 0);
        title.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1));

        toolbarButton("A−", "缩小网页文字").setOnClickListener(v -> changeFont(-10));
        toolbarButton("A+", "放大网页文字").setOnClickListener(v -> changeFont(10));
        toolbarButton("⛶", "隐藏或显示工具栏").setOnClickListener(v -> setFullscreen(!fullscreen));
        Button menu = toolbarButton("⋮", "菜单和连接设置");
        menu.setOnClickListener(v -> openMenu(menu));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(0xff19b7ed));
        progress.setIndeterminate(false);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));
        progress.setVisibility(View.GONE);

        errorBanner = new TextView(this);
        errorBanner.setTextColor(FG);
        errorBanner.setBackgroundColor(0xff8a342b);
        errorBanner.setTextSize(13);
        errorBanner.setPadding(dp(12), dp(9), dp(12), dp(9));
        errorBanner.setOnClickListener(v -> loadKodi());
        root.addView(errorBanner, new LinearLayout.LayoutParams(-1, -2));
        errorBanner.setVisibility(View.GONE);

        web = new WebView(this);
        web.setBackgroundColor(BG);
        web.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        toolbar.setVisibility(fullscreen ? View.GONE : View.VISIBLE);
    }

    private void configureWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadsImagesAutomatically(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setTextZoom(fontPercent);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);

        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                progress.setVisibility(View.VISIBLE);
                progress.setProgress(10);
                errorBanner.setVisibility(View.GONE);
            }

            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                injectCss();
                view.postDelayed(() -> injectCss(), 500);
                view.postDelayed(() -> injectCss(), 1500);
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                if (!req.isForMainFrame()) return false;
                Uri uri = req.getUrl();
                String scheme = uri.getScheme();
                if (scheme == null || "about".equals(scheme) || "javascript".equals(scheme)) return false;
                if (("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) && isKodiOrigin(uri)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "无法打开外部链接", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler, String requestHost, String realm) {
                if (requestHost != null && requestHost.equalsIgnoreCase(host) && !username.isEmpty()) {
                    handler.proceed(username, password);
                } else {
                    handler.cancel();
                    showMessage("此网页需要 HTTP 账号密码，请在 App 设置中填写 Kodi 账号和密码");
                }
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) {
                    showMessage("无法连接 Kodi：请确认电视端 Kodi 正在运行、IP 和端口正确。点此重试。");
                }
            }

            @Override public void onReceivedHttpError(WebView view, WebResourceRequest req, WebResourceResponse response) {
                if (req.isForMainFrame() && response.getStatusCode() >= 400) {
                    showMessage("Kodi 返回 HTTP " + response.getStatusCode() + "，请检查 HTTP 控制和账号设置。点此重试。");
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                if (newProgress >= 100) progress.setVisibility(View.GONE);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, PICK_FILE);
                    return true;
                } catch (ActivityNotFoundException ex) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "系统没有文件选择器", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        web.setDownloadListener((url, ua, disposition, mime, length) -> downloadFromKodi(url, ua, disposition, mime));
    }

    private boolean isKodiOrigin(Uri uri) {
        String scheme = uri.getScheme();
        String uriHost = uri.getHost();
        int uriPort = uri.getPort() < 0 ? ("https".equalsIgnoreCase(scheme) ? 443 : 80) : uri.getPort();
        return uriHost != null && uriHost.equalsIgnoreCase(host) && uriPort == port && "http".equalsIgnoreCase(scheme);
    }

    private String rootUrl() { return "http://" + host + ":" + port + "/"; }

    private void loadKodi() {
        if (host.isEmpty()) { showSettings(); return; }
        web.loadUrl(rootUrl());
    }

    private void showMessage(String s) {
        errorBanner.setText(s);
        errorBanner.setVisibility(View.VISIBLE);
    }

    private void changeFont(int delta) {
        fontPercent = Math.max(100, Math.min(220, fontPercent + delta));
        preferences.edit().putInt("font", fontPercent).apply();
        web.getSettings().setTextZoom(fontPercent);
        injectCss();
        Toast.makeText(this, "网页文字 " + fontPercent + "%", Toast.LENGTH_SHORT).show();
    }

    /**
     * CSS enhancement is additive: do not replace Chorus2 scripts, navigation, or settings.
     * Icon fonts are explicitly excluded so the navigation glyphs remain intact.
     */
    private void injectCss() {
        if (web == null) return;
        int normal = Math.round(13f * fontPercent / 100f);
        int small = Math.max(14, Math.round(normal * 0.90f));
        int heading = Math.round(normal * 1.20f);
        int target = largeTargets ? 42 : 0;
        String css = "html{-webkit-text-size-adjust:100%!important;}" +
            "body,body p,body li,body label,body input,body select,body textarea,body button," +
            "body .collection-item,body .dropdown-content li,body .modal-content," +
            "body .card-content,body .settings,body .setting,body .list-item{" +
            "font-size:" + normal + "px!important;line-height:1.42!important;}" +
            "body small,body .secondary-content,body .subtext,body .description{" +
            "font-size:" + small + "px!important;}" +
            "body h1,body h2,body h3,body h4,body .card-title{" +
            "font-size:" + heading + "px!important;line-height:1.3!important;}" +
            (largeTargets ? "@media(max-width:850px){button,.btn,body input,body select," +
                "body .collection-item,body .dropdown-content li{min-height:" + target + "px!important;}" +
                "body .dropdown-content li{height:auto!important;}}" : "");
        // Convert to a JS quoted string with no unescaped user content.
        String safeCss = css.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        String js = "(function(){try{" +
            "var node=document.getElementById('kca-mobile-enhance');" +
            "if(!node){node=document.createElement('style');node.id='kca-mobile-enhance';" +
            "(document.head||document.documentElement).appendChild(node);}" +
            "node.textContent='" + safeCss + "';" +
            "}catch(e){}})();";
        web.evaluateJavascript(js, null);
    }

    private void setFullscreen(boolean enabled) {
        fullscreen = enabled;
        preferences.edit().putBoolean("fullscreen", enabled).apply();
        toolbar.setVisibility(enabled ? View.GONE : View.VISIBLE);
        Toast.makeText(this, enabled ? "已隐藏工具栏，按手机返回键可恢复" : "已显示工具栏", Toast.LENGTH_SHORT).show();
    }

    private void openMenu(View anchor) {
        PopupMenu pop = new PopupMenu(this, anchor);
        pop.getMenu().add(0, 1, 0, "连接地址 / 字体 / 布局设置");
        pop.getMenu().add(0, 2, 1, "刷新网页");
        pop.getMenu().add(0, 3, 2, "返回 Chorus2 首页");
        pop.getMenu().add(0, 4, 3, "使用外部浏览器打开");
        pop.getMenu().add(0, 5, 4, "清除网页缓存（保留账号配置）");
        pop.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1: showSettings(); return true;
                case 2: web.reload(); return true;
                case 3: loadKodi(); return true;
                case 4: startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(rootUrl()))); return true;
                case 5: askClearCache(); return true;
            }
            return false;
        });
        pop.show();
    }

    private TextView caption(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(14);
        t.setTextColor(0xffe7eef3);
        t.setPadding(0, dp(12), 0, dp(4));
        return t;
    }

    private EditText input(String value, int type) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xff9daab3);
        e.setTextSize(17);
        e.setSingleLine(true);
        e.setInputType(type);
        e.setSelectAllOnFocus(true);
        return e;
    }

    private void showSettings() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout form = new LinearLayout(this);
        form.setPadding(dp(18), dp(5), dp(18), dp(10));
        form.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(form);
        form.addView(caption("Kodi 设备 IP 地址（不写 http://）"));
        EditText hostEdit = input(host, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        form.addView(hostEdit);
        form.addView(caption("HTTP 端口"));
        EditText portEdit = input(Integer.toString(port), InputType.TYPE_CLASS_NUMBER);
        form.addView(portEdit);
        form.addView(caption("Kodi HTTP 用户名（如未设置可留空）"));
        EditText userEdit = input(username, InputType.TYPE_CLASS_TEXT);
        form.addView(userEdit);
        form.addView(caption("Kodi HTTP 密码（如未设置可留空）"));
        EditText passEdit = input(password, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        form.addView(passEdit);
        form.addView(caption("网页字体大小：100%–220%"));
        fontLabel = caption(fontPercent + "%");
        fontLabel.setGravity(Gravity.CENTER_HORIZONTAL);
        form.addView(fontLabel);
        SeekBar fontBar = new SeekBar(this);
        fontBar.setMax(120);
        fontBar.setProgress(fontPercent - 100);
        form.addView(fontBar);
        fontBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { fontLabel.setText((progress + 100) + "%"); }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        CheckBox large = new CheckBox(this);
        large.setText("增大网页可点击区域（适合手机）");
        large.setTextSize(14);
        large.setTextColor(Color.WHITE);
        large.setChecked(largeTargets);
        large.setPadding(0, dp(10), 0, 0);
        form.addView(large);
        TextView note = caption("这是 Kodi 官方 Chorus2 网页的专用容器。原有菜单、媒体库、插件和 Chorus2 提供的设置保留。HTTP 账号只保存在本机应用私有配置中，但局域网 HTTP 传输本身不加密。");
        note.setTextColor(0xffb4c2cb);
        note.setTextSize(12);
        form.addView(note);

        new AlertDialog.Builder(this)
            .setTitle("Chorus2 网页 App 设置")
            .setView(scroll)
            .setNegativeButton("取消", (d, w) -> {})
            .setPositiveButton("保存并应用", (d, w) -> {
                String newHost = hostEdit.getText().toString().trim();
                newHost = newHost.replaceFirst("^https?://", "").replaceAll("/.*$", "");
                int newPort;
                try { newPort = Integer.parseInt(portEdit.getText().toString().trim()); }
                catch (NumberFormatException ex) { newPort = 8080; }
                if (!newHost.matches("[a-zA-Z0-9.\\-]+") || newPort < 1 || newPort > 65535) {
                    Toast.makeText(this, "IP 或端口不正确，设置未保存", Toast.LENGTH_LONG).show();
                    return;
                }
                boolean connectionChanged = !host.equals(newHost) || port != newPort ||
                        !username.equals(userEdit.getText().toString()) ||
                        !password.equals(passEdit.getText().toString());
                host = newHost;
                port = newPort;
                username = userEdit.getText().toString();
                password = passEdit.getText().toString();
                fontPercent = fontBar.getProgress() + 100;
                largeTargets = large.isChecked();
                preferences.edit()
                    .putString("host", host).putInt("port", port)
                    .putString("username", username).putString("password", password)
                    .putInt("font", fontPercent).putBoolean("largeTargets", largeTargets).apply();
                web.getSettings().setTextZoom(fontPercent);
                if (connectionChanged) {
                    web.clearHistory();
                    loadKodi();
                } else {
                    injectCss();
                }
            })
            .show();
    }

    private void askClearCache() {
        new AlertDialog.Builder(this)
            .setTitle("清除网页缓存？")
            .setMessage("会清除缓存文件并重新加载 Chorus2。不会删除 Kodi 电视端的媒体库、插件或设置。")
            .setNegativeButton("取消", (d,w) -> {})
            .setPositiveButton("清除", (d,w) -> { web.clearCache(true); CookieManager.getInstance().flush(); loadKodi(); })
            .show();
    }

    private void downloadFromKodi(String url, String ua, String disposition, String mime) {
        try {
            Uri uri = Uri.parse(url);
            if (!isKodiOrigin(uri)) {
                Toast.makeText(this, "为了避免泄露凭据，仅在应用内下载 Kodi 服务器上的文件", Toast.LENGTH_LONG).show();
                return;
            }
            DownloadManager.Request req = new DownloadManager.Request(uri);
            req.setTitle(android.webkit.URLUtil.guessFileName(url, disposition, mime));
            req.setMimeType(mime);
            req.addRequestHeader("User-Agent", ua == null ? "KodiChorusMobile" : ua);
            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null) req.addRequestHeader("Cookie", cookies);
            if (!username.isEmpty()) {
                String basic = username + ":" + password;
                String encoded = android.util.Base64.encodeToString(basic.getBytes(java.nio.charset.StandardCharsets.UTF_8), android.util.Base64.NO_WRAP);
                req.addRequestHeader("Authorization", "Basic " + encoded);
            }
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                    android.webkit.URLUtil.guessFileName(url, disposition, mime));
            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            manager.enqueue(req);
            Toast.makeText(this, "开始下载至 Download 文件夹", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            Toast.makeText(this, "下载未启动：" + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        web.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (fullscreen) { setFullscreen(false); return; }
        if (web.canGoBack()) { web.goBack(); return; }
        super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (web != null) {
            ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
        }
        super.onDestroy();
    }
}
